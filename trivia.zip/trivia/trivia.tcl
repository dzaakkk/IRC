#PLEASE consult the file trivia.readme.html for detailed
#explanations of these variables.

set tgqdb "/home/yourname/eggdir/scripts/trivia.questions"
set tgscf "/home/yourname/eggdir/scripts/trivia.scores"
set tgerrfil "/home/yourname/eggdir/scripts/trivia.errors"
set tgchan "#lame"
set tgpointsperanswer 1
set tgmaxhint 3
set tgstreakmin 3
set tgmaxmissed 0
set tghintchar "@"
set tgtimehint 30
set tgtimenext 10
set tgcongrats [list "Поздравления" "Браво" "Хубава работа" "Точно така" "Справи се" "Така се прави" "Покажи им как се прави"]
set tgnobodygotit [list "Никой не позна." "Ало? Има ли някой вкъщи?" "Ще трябва да опиташ повече!" "Тези прекалено трудни ли са за теб?" "Сам ли съм тук, или какво?" "Така няма да спечелиш точки!"]
set tgtrythenextone [list "Да видим дали ще познаеш следващия..." "Приготви се за следващия..." "Може би ще познаеш следващия..." "Опитай да познаеш следващия..." "Ето го следващия..."]
set tgusebold 0
set tgcmdhelp "?"
set tgcmdstart "!start"
set tgflagsstart -|-
set tgcmdstop "!stop"
set tgflagsstop o|o
set tgcmdhint "!hint"
set tgflagshint o|o
set tgcmdskip "!skip"
set tgflagsskip o|o
set tgcmdreset "reset"
set tgflagsreset n|n
set tgcmdlookup "score"
set tgcmdtarget "target"
set tgcmderror "error"
set tgerrremindtime 15

#You'll need to remove the next line. It's just there to make sure you make
#some effort to edit the settings...
die "* [file tail [info script]]: you didn't edit the settings like you were told, did you?"

######################################################################
#      You shouldn't need to modify anything beyond this point.      #
######################################################################
#Misc checks & var initialisations
if {![file exists $tgqdb]} {die "[file tail [info script]]: $tgqdb does not exist!"}
if {![info exists alltools_loaded]||$allt_version<204} {die "[file tail [info script]]: this script requires alltools.tcl v1.6 (or higher) to be loaded!"}
if {![info exists tgplaying]} {set tgplaying 0}
if {![info exists tghintnum]} {set tghintnum 0}
if {![info exists tgmissed]} {set tgmissed 0}

#Binds
bind pub $tgflagsstart $tgcmdstart tgstart
bind pub $tgflagsstop $tgcmdstop tgstop
bind pub $tgflagshint $tgcmdhint tgforcehint
bind pub $tgflagsskip $tgcmdskip tgskip
bind join -|- "$tgchan *" tgjoinmsg
bind msg - $tgcmdhelp tggivehelp
bind msg - $tgcmdlookup tgscorelookup
bind msg - $tgcmdtarget tgtargetlookup
bind msg - $tgcmderror tgerror
bind msg $tgflagsreset "$tgcmdreset" tgresetscores
bind kick - "$tgchan $botnick" tgbotgotkicked
bind evnt - disconnect-server tgbotgotdisconnected

#starts the game if it isn't running.
proc tgstart {nick host hand chan text} {
 global tgplaying tgstreak tgchan tgerrremindtime tgerrremindtimer tgmissed
 if {[strlwr $tgchan]==[strlwr $chan]} {
  if {$tgplaying==0} {
   tggamemsg "\00303Trivia game started by $nick!"
   tgnext
   set tgplaying 1
   set tgstreak 0
   set tgmissed 0
   set tgerrremindtimer [timer $tgerrremindtime tgerrremind]
  }
  return 1
 }
}

#stops the game if it's running.
proc tgstop {nick host hand chan text} {
 global tghinttimer tgnexttimer tgplaying tgchan tgcurrentanswer tgstreak tgstreakmin
 global tgerrremindtimer
 if {[strlwr $tgchan]==[strlwr $chan]} {
  if {$tgplaying==1} {
   tggamemsg "\00304Trivia game stopped by $nick!"
   if {$tgstreakmin>0&&[lindex [split $tgstreak ,] 1]>=$tgstreakmin} { tgstreakend }
   set tgstreak 0
   set tgplaying 0
   catch {unbind pubm -|- "$tgchan $tgcurrentanswer" tgcorrectanswer}
   if {[utimerexists tghint]!=""} {killutimer $tghinttimer}
   if {[utimerexists tgnext]!=""} {killutimer $tgnexttimer}
   if {[timerexists tgerrremind]!=""} {killtimer $tgerrremindtimer}
  }
  return 1
 }
}

#gives a hint if there is currently a question to answer.
proc tgforcehint {nick host hand chan text} {
 global tghinttimer tgnexttimer tgplaying tgchan tgcurrentanswer tgstreak tgstreakmin
 if {[strlwr $tgchan]==[strlwr $chan]} {
  if {$tgplaying==1&&[utimerexists tghint]!=""} {
   killutimer $tghinttimer
   tghint
  }
  return 1
 }
}

#skips the current question if one has been asked.
proc tgskip {nick host hand chan text} {
 global tghinttimer tgnexttimer tgplaying tgchan tgcurrentanswer tgstreak tgstreakmin tgtimenext
 if {[strlwr $tgchan]==[strlwr $chan]} {
  if {$tgplaying==1&&[utimerexists tghint]!=""} {
   tggamemsg "\00310Skipping to next question by $nick's request..."
   if {$tgstreakmin>0&&[lindex [split $tgstreak ,] 1]>=$tgstreakmin} { tgstreakend }
   set tgstreak 0
   unbind pubm -|- "$tgchan $tgcurrentanswer" tgcorrectanswer
   killutimer $tghinttimer
   set tgnexttimer [utimer $tgtimenext tgnext]
  }
  return 1
 }
}

#reminds channel how to report errors in questions/answers
proc tgerrremind {} {
 global tgerrremindtimer tgerrremindtime botnick tgcmderror
 tggamemsg "\00306Remember: to report errors in questions/answers, type \00307/msg $botnick $tgcmderror <number> \[description\]"
 set tgerrremindtimer [timer $tgerrremindtime tgerrremind]
}


#bot got kicked. stop the game.
proc tgbotgotkicked {nick host hand chan targ text} {
 tgquietstop
}

#bot got disconnected. stop the game.
proc tgbotgotdisconnected {disconnect-server} {
 tgquietstop
}

#stops the game quietly.
proc tgquietstop {} {
 global tgplaying tgstreak tgchan tgcurrentanswer tghinttimer tgnexttimer tgerrremindtimer
 if {$tgplaying==1} {
  set tgstreak 0
  set tgplaying 0
  catch {unbind pubm -|- "$tgchan $tgcurrentanswer" tgcorrectanswer}
  if {[utimerexists tghint]!=""} {killutimer $tghinttimer}
  if {[utimerexists tgnext]!=""} {killutimer $tgnexttimer}
  if {[timerexists tgerrremind]!=""} {killtimer $tgerrremindtimer}
 }
}

#reads the question database.
proc tgreadqdb {} {
 global tgqdb tgquestionstotal tgquestionslist
 set tgquestionstotal 0
 set tgquestionslist ""	
 set qfile [open $tgqdb r]
 while {![eof $qfile]} {
  lappend tgquestionslist [gets $qfile]
  incr tgquestionstotal
 }
 close $qfile
}

#selects the next question.
proc tgnext {} {
 global tgqdb tgcurrentquestion tgcurrentanswer tgquestionnumber tgquestionstotal
 global tghintnum tgchan tgquestionslist
 tgreadqdb
 set tgquestionnumber [rand [llength $tgquestionslist]]			
 set tgquestionselected [lindex $tgquestionslist $tgquestionnumber]
 set tgcurrentquestion [lindex [split $tgquestionselected |] 1]
 set tgcurrentanswer [strlwr [lindex [split $tgquestionselected |] 0]]
 unset tghintnum
 tghint
 bind pubm -|- "$tgchan $tgcurrentanswer" tgcorrectanswer
 return
}

#shows timed hints.
proc tghint {} {
 global tgmaxhint tghintnum tgcurrentanswer tghinttimer tgchan
 global tgtimehint tghintchar tgquestionnumber tgquestionstotal
 global tgcurrentquestion tghintcharsused tgnexttimer tgtimenext tgstreak tgstreakmin
 global tgnobodygotit tgtrythenextone tgmissed tgmaxmissed tgcmdstart
 if {[catch {incr tghintnum}]!=0} {set tghintnum 0}
 if {$tghintnum >= [expr $tgmaxhint+1]} {
  incr tgmissed
  set _msg ""
  append _msg "\00310[lindex $tgnobodygotit [rand [llength $tgnobodygotit]]]"
  if {$tgmaxmissed>0&&$tgmissed>=$tgmaxmissed} {
   append _msg " That's $tgmissed questions gone by unanswered! The game is now automatically disabled. To start the game again, type $tgcmdstart"
   tgquietstop
  } else {
   append _msg " [lindex $tgtrythenextone [rand [llength $tgtrythenextone]]]"
  }
  tggamemsg "$_msg"
  if {$tgstreakmin>0&&[lindex [split $tgstreak ,] 1]>=$tgstreakmin} { tgstreakend }
  set tgstreak 0
  catch {unbind pubm -|- "$tgchan $tgcurrentanswer" tgcorrectanswer}
  if {$tgmaxmissed==0||$tgmissed<$tgmaxmissed} {
   set tgnexttimer [utimer $tgtimenext tgnext]
  }
  return
 } elseif {$tghintnum == 0} {
  set i 0
  set _hint {}
  set tghintcharsused {}
  regsub -all -- "\[A-Za-z0-9\]" $tgcurrentanswer $tghintchar _hint
 } elseif {$tghintnum == 1} {
  set i 0
  set _hint {}
  while {$i<[llength [split $tgcurrentanswer " "]]} {
   set _word [lindex [split $tgcurrentanswer " "] $i]
   set j 0
   set _newword {}
   while {$j<[strlen $_word]} {
    if {$j==0} {
     append _newword [stridx $_word $j]
     lappend tghintcharsused $i,$j
    } else {
     if {[string is alnum [stridx $_word $j]]} {
      append _newword $tghintchar
     } else {
      append _newword [stridx $_word $j]
      lappend tghintcharsused $i,$j
     }
    }
    incr j
   }
   lappend _hint $_newword
   incr i
  }
  } else {
   set i 0
   set _hint {}    
   while {$i<[llength [split $tgcurrentanswer " "]]} {
    set _word [lindex [split $tgcurrentanswer " "] $i]
    set j 0
    set _newword {}
    set _selected [rand [strlen $_word]]
    regsub -all -- "\[^A-Za-z0-9\]" $_word "" _wordalnum
    if {[strlen $_wordalnum]>=$tghintnum} {
     while {[lsearch $tghintcharsused $i,$_selected]!=-1||[string is alnum [stridx $_word $_selected]]==0} {
      set _selected [rand [strlen $_word]]
     }
    }
    lappend tghintcharsused $i,$_selected
    while {$j<[strlen $_word]} {
     if {[lsearch $tghintcharsused $i,$j]!=-1||[string is alnum [stridx $_word $j]]==0} {
      append _newword [stridx $_word $j]
     } else {
      if {[string is alnum [stridx $_word $j]]} {
       append _newword $tghintchar
      }
    }
    incr j
   }
   lappend _hint $_newword
   incr i
  }
 }
 tggamemsg "\00304===== Question [expr $tgquestionnumber+1]/$tgquestionstotal [expr $tghintnum?"(Hint $tghintnum/$tgmaxhint)":""] ====="
 tggamemsg "\00312[strupr $tgcurrentquestion]"
 tggamemsg "\00303Hint: [strupr $_hint]"
 set tghinttimer [utimer $tgtimehint tghint]
}

#triggered when someone says the correct answer.
proc tgcorrectanswer {nick host hand chan text} {
 global tgcurrentanswer tghinttimer tgtimenext tgchan tgnexttimer tgstreak tgstreakmin
 global tgscoresbyname tgranksbyname tgranksbynum tgcongrats tgscorestotal tgmissed
 tggetscores
 if {![info exists tgranksbyname($nick)]} {
  set _oldrank 0
 } else {
  set _oldrank [lindex [split $tgranksbyname($nick) ,] 0]
 }
 tgincrscore $nick
 tggetscores
 set _newrank [lindex [split $tgranksbyname($nick) ,] 0]
 set _msg "\00306[lindex $tgcongrats [rand [llength $tgcongrats]]] \00304$nick\00306! The answer was \00304[strupr $tgcurrentanswer]\00306."
 if {$_newrank<$_oldrank} {
  if {$_newrank==1} {
   append _msg " You are now in first place!"
  } else {
   append _msg " You are now ranked \00304[tgnumsuf [lindex [split $tgranksbyname($nick) ,] 0]]\00306 of \00304$tgscorestotal\00306, behind \00304[lindex [split $tgranksbynum([expr $_newrank-1]) ,] 0]\00306 with \00304[lindex [split $tgranksbynum([expr $_newrank-1]) ,] 1]\00306."
  }
 }
 tggamemsg "$_msg"
 if {$tgstreak!=0} {
  if {[lindex [split $tgstreak ,] 0]==$nick} {
   set tgstreak $nick,[expr [lindex [split $tgstreak ,] 1]+1]
   if {$tgstreakmin>0&&[lindex [split $tgstreak ,] 1]>=$tgstreakmin} {
    tggamemsg "\00312$nick is on a winning streak! [lindex [split $tgstreak ,] 1] in a row so far!"
   }
  } else {
   if {$tgstreakmin>0&&[lindex [split $tgstreak ,] 1]>=$tgstreakmin} { tgstreakend }
   set tgstreak $nick,1
  }
 } else {
  set tgstreak $nick,1
 }
 set tgmissed 0
 tgshowscores
 unbind pubm -|- "$tgchan $tgcurrentanswer" tgcorrectanswer
 killutimer $tghinttimer
 set tgnexttimer [utimer $tgtimenext tgnext]
 return 1
}

#read current scores from file, sort and store in variable.
proc tggetscores {} {
 global tgscf tgscorestotal tgscores tgscoresbyname tgranksbyname tgranksbynum
 if {[file exists $tgscf]&&[file size $tgscf]>2} {
  set _sfile [open $tgscf r]
  set tgscores [lsort -dict -decreasing [split [gets $_sfile] " "]]
  close $_sfile
  set tgscorestotal [llength $tgscores]
 } else {
  set tgscores ""
  set tgscorestotal 0
 }
 if {[info exists tgscoresbyname]} {unset tgscoresbyname}
 if {[info exists tgranksbyname]} {unset tgranksbyname}
 if {[info exists tgranksbynum]} {unset tgranksbynum}
 set i 0
 while {$i<[llength $tgscores]} {
  set _item [lindex $tgscores $i]
  set _nick [lindex [split $_item ,] 2]
  set _score [lindex [split $_item ,] 0]
  set tgscoresbyname($_nick) $_score
  set tgranksbyname($_nick) [expr $i+1],$_score
  set tgranksbynum([expr $i+1]) $_nick,$_score
  incr i
 }
 return
}

#increment someone's score.
proc tgincrscore {who} {
 global tgscores tgscf tgpointsperanswer tgscorestotal
 tggetscores
 if {$tgscorestotal>0} {
  set i 0
  if {[lsearch $tgscores "*,*,$who"]==-1} {
   append _newscores "1,[expr 1000000000000.0/[unixtime]],$who "
  }
  while {$i<[llength $tgscores]} {
   set _item [lindex $tgscores $i]
   set _nick [lindex [split $_item ,] 2]
   set _time [lindex [split $_item ,] 1]
   set _score [lindex [split $_item ,] 0]
   if {[strlwr $who]==[strlwr $_nick]} {
    append _newscores "[expr $_score+$tgpointsperanswer],[expr 1000000000000.0/[unixtime]],$who[expr [expr [llength $tgscores]-$i]==1?"":"\ "]"
   } else {
    append _newscores "$_score,$_time,$_nick[expr [expr [llength $tgscores]-$i]==1?"":"\ "]"
   }
   incr i
  }
 } else {
  append _newscores "1,[expr 1000000000000.0/[unixtime]],$who"
 }
 set _sfile [open $tgscf w]
 puts $_sfile "$_newscores"
 close $_sfile
 return
}

#shows the current scores on channel.
proc tgshowscores {} {
 global tgscores tgchan tgscorestotal
 tggetscores
 set i 0
 while {$i<[llength $tgscores]} {
  set _item [lindex $tgscores $i]
  set _nick [lindex [split $_item ,] 2]
  set _score [lindex [split $_item ,] 0]
  if {$i==0} {
   append _scores "\00304$_nick $_score"
  } elseif {$i==1} {
   append _scores ", \00303$_nick $_score"
  } elseif {$i==2} {
   append _scores ", \00312$_nick $_score"
  } elseif {[onchan $_nick $tgchan]} {
   append _scores ", \00306$_nick $_score"
  }
  incr i
 }
 tggamemsg "\00306The scores: $_scores"
}

#reset current scores.
proc tgresetscores {nick host hand text} {
 global tgscf tgscorestotal tgscores
 if {[file exists $tgscf]&&[file size $tgscf]>2} {
  set _sfile [open $tgscf w]
  puts $_sfile ""
  close $_sfile
  set tgscores ""
  set tgscorestotal 0
 }
 tggamemsg "\00304===== Score table reset by $nick! ====="
 return 1
}

#triggered when a winning streak ends.
proc tgstreakend {} {
  global tgstreak
  tggamemsg "\00312So much for [lindex [split $tgstreak ,] 0]'s winning streak."
  return
}

#triggered when someone joins trivia chan.
proc tgjoinmsg {nick host hand chan} {
 global botnick tgplaying tgcmdhelp tgcmdstart
 if {$nick != $botnick} {
  putnotc $nick "Welcome to $botnick's trivia channel. Trivia game is currently \002[expr $tgplaying?"on\002.":"off\002. To start the game, type \002$tgcmdstart\002."] Please type \002/MSG $botnick [strupr $tgcmdhelp]\002 if you need help. Enjoy your stay! :-)"
 }
}

#triggered when someone /msgs the bot with the score lookup command.
proc tgscorelookup {nick host hand text} {
 global tgscoresbyname tgranksbyname tgscorestotal
 if {$text==""} { set text $nick } else { set text [lindex [split $text " "] 0] }
 tggetscores
 set _array [array get tgscoresbyname]
 set _index [lsearch [strlwr "$_array"] [strlwr "$text"]]
 if {$_index==-1} {
  if {[strlwr $text]==[strlwr $nick]} {
   set _who "\00306You are"
  } else {
   set _who "\00304$text \00306is"
  }
  putnotc $nick "[tgbold]$_who \00306not on the score list."
 } else {
  set _nick [lindex $_array $_index]
  if {[strlwr $_nick]==[strlwr $nick]} {
   set _who "\00306You are"
  } else {
   set _who "\00304$_nick \00306is"
  }
  putnotc $nick "[tgbold]$_who on \00304$tgscoresbyname($_nick)\00306, ranked \00304[tgnumsuf [lindex [split $tgranksbyname($_nick) ,] 0]] \00306of \00304$tgscorestotal\00306."
 }
 return 1
}

#triggered when someone /msgs the bot with the target lookup command.
proc tgtargetlookup {nick host hand text} {
 global tgscoresbyname tgranksbyname tgscorestotal tgranksbynum
 tggetscores
 set _array [array get tgscoresbyname]
 set _index [lsearch [strlwr "$_array"] [strlwr "$nick"]]
 set _nick [lindex $_array $_index]
 if {$_index==-1} {
  putnotc $nick "[tgbold]\00306You are not on the score list."
 } elseif {$tgranksbyname($_nick)==1} {
  putnotc $nick "[tgbold]\00304You're in first place!"
 } else {
  set _myrank [lindex [split $tgranksbyname($_nick) ,] 0]
  set _myscore [lindex [split $tgscoresbyname($_nick) ,] 0]
  set _tgtrank [expr [lindex [split $tgranksbyname($_nick) ,] 0]-1]
  set _tgtnick [lindex [split $tgranksbynum($_tgtrank) ,] 0]
  set _tgtscore [lindex [split $tgranksbynum($_tgtrank) ,] 1]
  putnotc $nick "[tgbold]\00306You are on \00304$_myscore\00306. Your next target is \00304$_tgtnick \00306with \00304$_tgtscore\00306, ranked \00304[tgnumsuf $_tgtrank] \00306of \00304$tgscorestotal\00304."
 }
 return 1
}

#triggered when someone /msgs the bot with the target lookup command.
proc tgerror {nick host hand text} {
 global tgquestionstotal tgquestionslist tgerrfil
 if {$text==""||![string is int [lindex $text 0]]} {
  putnotc $nick "[tgbold]\00306You need to specify the number of the question."
  return
 }
 tgreadqdb
 set _qnum [lindex $text 0]
 if {$_qnum>$tgquestionstotal} {
  putnotc $nick "[tgbold]\00306No such question."
  return
 }
 set _qques [lindex [split [lindex $tgquestionslist [expr $_qnum-1]] |] 1]
 set _qans [lindex [split [lindex $tgquestionslist [expr $_qnum-1]] |] 0]
 set _desc [lrange $text 1 end]
 if {$_desc==""} { set _desc "No further info given for this error." }
 set _file [open $tgerrfil a]
 puts $_file "Reported by:\t$nick"
 puts $_file "Question #:\t$_qnum"
 puts $_file "Question:\t$_qques"
 puts $_file "Answer:\t\t$_qans"
 puts $_file "Comments:\t$_desc"
 puts $_file "--------------------------------------------------------------------------------"
 close $_file
 putnotc $nick "[tgbold]\00306Thanks for reporting the error."
 return 1
}

#triggered when someone /msgs the bot with the help command.
proc tggivehelp {nick host hand {text ""}} {
 global botnick tgcmdlookup tgcmdhelp tgcmdstart tgcmdstop tgchan tgflagsstop
 global tgcmdstop tgflagshint tgcmdhint tgflagsskip tgcmdskip tgflagsreset tgcmdreset
 global tgcmdtarget tgcmderror
 if {$text==""} {
  putnotc $nick "You have access to the following /MSG commands:"
  putnotc $nick "To use, /MSG $botnick <command>"
  putnotc $nick "  \002[strupr $tgcmdlookup]\002 \[nick\]"
  putnotc $nick "   -- Shows you the rank & score of \[nick\], if specified,"
  putnotc $nick "    otherwise, shows you your own rank & score."
  putnotc $nick "  \002[strupr $tgcmdtarget]\002"
  putnotc $nick "   -- Shows you the rank & score of the person ranked"
  putnotc $nick "    one above you."
  putnotc $nick "  \002[strupr $tgcmderror]\002 <number> \[description\]"
  putnotc $nick "   -- Reports an error in question <number>"
  putnotc $nick "    The description is optional, but helpful."
  if {[matchattr $hand $tgflagsreset $tgchan]} {
   putnotc $nick "  \002[strupr $tgcmdreset]\002"
   putnotc $nick "   -- Resets the score table."
  }
  putnotc $nick "For a list of channel commands, /MSG $botnick [strupr $tgcmdhelp] PUBCMDS"
 }
 if {[strlwr $text]=="pubcmds"} {
  putnotc $nick "You have access to the following channel commands:"
  putnotc $nick "  \002$tgcmdstart\002 -- starts the trivia game."
  if {[matchattr $hand $tgflagsstop $tgchan]} {
   putnotc $nick "  \002$tgcmdstop\002 -- stops the trivia game."
  }
  if {[matchattr $hand $tgflagshint $tgchan]} {
   putnotc $nick "  \002$tgcmdhint\002 -- shows a hint."
  }
  if {[matchattr $hand $tgflagsskip $tgchan]} {
   putnotc $nick "  \002$tgcmdskip\002 -- skips current question."
  }
  putnotc $nick "For a list of /MSG commands, /MSG $botnick [strupr $tgcmdhelp]"
 }
 return 1
}

#misc aliases
proc tggamemsg {what} {global tgchan;putquick "PRIVMSG $tgchan :[tgbold]$what"}
proc tggamenotc {who what} {putquick "NOTICE $who :$what"}
proc tgnumsuf {num} {set _last1 [string range $num [expr [strlen $num]-1] end];set _last2 [string range $num [expr [strlen $num]-2] end];if {$_last1=="1"&&$_last2!="11"} {return "[expr $num]st"} elseif {$_last1=="2"&&$_last2!="12"} {return "[expr $num]nd"} elseif {$_last1=="3"&&$_last2!="13"} {return "[expr $num]rd"} else {return "[expr $num]th"}}
proc tgbold {} {global tgusebold;if {$tgusebold==1} {return "\002"}}

putlog "* [file tail [info script]] by Uncle Sevdalin` loaded."
tgreadqdb
putlog "* $tgquestionstotal questions in $tgqdb"
